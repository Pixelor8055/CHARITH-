
import React, { useState } from 'react'

const initialPosts = [
  { id: 1, user: "RoguePlayer", content: "Finally ranked up to Diamond! Tips?", likes: 24 },
  { id: 2, user: "PixelMage", content: "Custom controller skins now in stock — drop your ideas.", likes: 12 },
];

const products = [
  { id: 1, name: "Pro Controller Skin - Nebula", price: "₹1,299" },
  { id: 2, name: "Custom Mousepad XL", price: "₹799" },
];

const services = [
  { id: 1, title: "Controller Customization", desc: "Full-body painting, grips, custom buttons." },
  { id: 2, title: "Personal Coaching", desc: "1-on-1 sessions for FPS aim training." },
];

const creatorsList = [
  { id: 1, name: "NyxStreams", handle: "@nyx", bio: "FPS streamer • Modder • Chill vibes", links: { twitch: "https://twitch.tv/nyx" } },
  { id: 2, name: "ArtOfPixel", handle: "@pixelart", bio: "Controller skins, digital art commissions", links: { insta: "https://instagram.com/artofpixel" } },
  { id: 3, name: "CoachRyu", handle: "@ryu", bio: "Aim coach • 1-on-1 sessions", links: { twitter: "https://twitter.com/coachryu" } },
];

export default function Home() {
  const [route, setRoute] = useState('home')
  const [posts, setPosts] = useState(initialPosts)
  const [query, setQuery] = useState('')

  function createPost(text) {
    if (!text || !text.trim()) return;
    const newPost = { id: Date.now(), user: 'You', content: text, likes: 0 }
    setPosts([newPost, ...posts])
  }

  return (
    <div className="min-h-screen">
      <header className="bg-gradient-to-r from-indigo-700 via-pink-600 to-rose-500 p-4 shadow-lg">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/10 rounded flex items-center justify-center text-xl font-bold">C</div>
            <div>
              <h1 className="text-xl font-extrabold">Charith</h1>
              <div className="text-xs opacity-80">For Gamers. By Gamers. Forever.</div>
            </div>
          </div>
          <nav className="flex items-center gap-4">
            <NavButton active={route === 'home'} onClick={() => setRoute('home')}>Home</NavButton>
            <NavButton active={route === 'products'} onClick={() => setRoute('products')}>Products</NavButton>
            <NavButton active={route === 'services'} onClick={() => setRoute('services')}>Services</NavButton>
            <NavButton active={route === 'franchise'} onClick={() => setRoute('franchise')}>Franchise</NavButton>
            <NavButton active={route === 'creators'} onClick={() => setRoute('creators')}>Creators</NavButton>
            <button className="ml-2 rounded-md px-3 py-2 bg-white/10 hover:bg-white/15">Login</button>
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        <section className="lg:col-span-2">
          {route === 'home' && (
            <HomeFeed posts={posts} onCreate={createPost} />
          )}

          {route === 'products' && <Products items={products} />}
          {route === 'services' && <Services items={services} />}
          {route === 'franchise' && <Franchise />}
          {route === 'creators' && <Creators items={creatorsList} />}
        </section>

        <aside className="hidden lg:block">
          <ProfileCard />
          <CommunityTips />
          <div className="mt-4">
            <h3 className="text-sm font-semibold mb-2">Quick Links</h3>
            <ul className="text-xs space-y-2 opacity-90">
              <li>How to open a franchise</li>
              <li>Partner with us</li>
              <li>Creator program</li>
              <li>Creators Hub</li>
            </ul>
          </div>
        </aside>
      </main>

      <footer className="p-4 text-center text-xs text-slate-400">© {new Date().getFullYear()} Charith — Built for gamers</footer>
    </div>
  )
}

/* Helper Components */

function NavButton({ children, active, onClick }) {
  return (
    <button onClick={onClick} className={`px-3 py-2 rounded-md text-sm ${active ? 'bg-white/20 font-semibold' : 'hover:bg-white/5'}`}>
      {children}
    </button>
  )
}

function HomeFeed({ posts, onCreate }) {
  const [text, setText] = useState('')
  return (
    <div>
      <div className="mb-4 p-4 bg-white/3 rounded">
        <h2 className="text-lg font-bold">Feed</h2>
        <p className="text-xs opacity-80">Share your thoughts, clips, or gear ideas.</p>

        <div className="mt-4 flex gap-2">
          <input value={text} onChange={(e) => setText(e.target.value)} placeholder="What's on your mind?" className="flex-1 p-3 rounded bg-transparent border border-white/10" />
          <button onClick={() => { onCreate(text); setText('') }} className="px-4 py-2 bg-indigo-600 rounded">Post</button>
        </div>
      </div>

      <div className="space-y-4">
        {posts.map((p) => (
          <article key={p.id} className="p-4 bg-white/2 rounded">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-white/6 rounded-full flex items-center justify-center">{p.user[0]}</div>
              <div>
                <div className="text-sm font-semibold">{p.user} <span className="text-xs opacity-70">— Gamer</span></div>
                <p className="mt-1 text-sm">{p.content}</p>
                <div className="mt-2 text-xs opacity-80 flex gap-4">
                  <button className="hover:underline">Like ({p.likes})</button>
                  <button className="hover:underline">Comment</button>
                </div>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}

function Products({ items }) {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-3">Products</h2>
      <p className="text-sm opacity-80 mb-4">Custom gear and limited drops. Order or request customizations.</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {items.map((it) => (
          <div key={it.id} className="p-4 bg-white/3 rounded">
            <div className="font-semibold">{it.name}</div>
            <div className="text-sm opacity-80">{it.price}</div>
            <div className="mt-3">
              <button className="px-3 py-2 rounded bg-pink-600">Order</button>
              <button className="ml-2 px-3 py-2 rounded border border-white/10">Customize</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function Services({ items }) {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-3">Services</h2>
      <div className="space-y-3">
        {items.map((s) => (
          <div key={s.id} className="p-4 bg-white/3 rounded">
            <div className="font-semibold">{s.title}</div>
            <div className="text-sm opacity-80">{s.desc}</div>
            <div className="mt-3">
              <button className="px-3 py-2 rounded bg-indigo-600">Book</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function Franchise() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-3">Franchise & Partnerships</h2>
      <p className="text-sm opacity-80 mb-4">Bring Charith to your city — join our franchise program. Low startup cost, training, supply chain, and branding support.</p>

      <div className="p-4 bg-white/3 rounded">
        <h3 className="font-semibold">Why partner with us?</h3>
        <ul className="mt-2 text-sm opacity-90 list-disc list-inside">
          <li>Proven product-market fit in gaming gear</li>
          <li>Centralized customization templates</li>
          <li>Marketing & influencer toolkits</li>
        </ul>

        <div className="mt-4">
          <button className="px-4 py-2 rounded bg-rose-500">Apply for Franchise</button>
        </div>
      </div>
    </div>
  )
}

function Creators({ items }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-2xl font-bold">Creators Hub</h2>
          <p className="text-sm opacity-80">Showcase streamers, artists, and modders — hire, follow, or commission.</p>
        </div>
        <div>
          <button className="px-4 py-2 rounded bg-indigo-600">Apply as Creator</button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {items.map((c) => (
          <div key={c.id} className="p-4 bg-white/3 rounded">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-white/6 flex items-center justify-center text-lg font-bold">{c.name[0]}</div>
              <div>
                <div className="font-semibold">{c.name} <span className="text-xs opacity-70">{c.handle}</span></div>
                <div className="text-xs opacity-80">{c.bio}</div>
              </div>
            </div>

            <div className="mt-3 flex gap-2">
              <button className="px-3 py-2 rounded bg-pink-600">Follow</button>
              <button className="px-3 py-2 rounded border border-white/10">Message</button>
              <a href={c.links.twitch || c.links.insta || c.links.twitter} target="_blank" rel="noreferrer" className="ml-auto text-xs opacity-80">Visit</a>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-white/4 rounded">
        <h3 className="font-semibold">Creator Resources</h3>
        <ul className="text-xs mt-2 list-disc list-inside opacity-90">
          <li>Creator onboarding & verification</li>
          <li>Revenue split & monetization tools</li>
          <li>Commission management</li>
        </ul>
      </div>
    </div>
  )
}

function ProfileCard() {
  return (
    <div className="p-4 bg-white/3 rounded">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-full bg-white/6 flex items-center justify-center">Y</div>
        <div>
          <div className="font-semibold">You</div>
          <div className="text-xs opacity-80">Level 12 • Streamer</div>
        </div>
      </div>
      <div className="mt-3 text-xs opacity-80">Bio: I love FPS games and custom paintjobs.</div>
    </div>
  )
}

function CommunityTips() {
  return (
    <div className="p-4 bg-white/3 rounded mt-4">
      <h4 className="font-semibold text-sm">Community Tips</h4>
      <ol className="text-xs mt-2 list-decimal list-inside opacity-90">
        <li>Be respectful — no hate speech.</li>
        <li>Use the customization request form for custom orders.</li>
        <li>Report scams to support.</li>
      </ol>
    </div>
  )
}
