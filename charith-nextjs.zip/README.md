Charith - Next.js + Tailwind (deploy-ready)
------------------------------------------
This project is a minimal Next.js (pages/) app with Tailwind CSS and the Charith UI component.

How to deploy quickly:
1. Unzip and push this folder to a new GitHub repository named `charith`.
2. Sign in to Vercel with GitHub, import the `charith` repo and deploy (Vercel auto-detects Next.js).
3. Locally: run `npm install` then `npm run dev` to run locally.

Notes:
- This repo includes placeholder data and UI only (no backend). For a full production app, add APIs, authentication, database, and storage.
- Creators dashboard and profile templates are included as UI pages.
